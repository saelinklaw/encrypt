There are two public DB entries - one for Windows and one for the UEFI Certificate Authority (CA).
Windows DB: http://www.microsoft.com/pkiops/certs/MicWinProPCA2011_2011-10-19.crt
UEFI DB: http://www.microsoft.com/pkiops/certs/MicCorUEFCA2011_2011-06-27.crt 
