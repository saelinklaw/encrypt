# VeraCrypt-DCS
VeraCrypt EFI Bootloader for EFI Windows system encryption (LGPL)
