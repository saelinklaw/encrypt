///////////////////////////////////////////////
//
// **************************
// ** ENGLISH - 10/Jul/2017 **
//
// Project: libObfuscate v2.00
//
// This software is released under:
// * LGPL 3.0: "www.gnu.org/licenses/lgpl.html"
//
// You�re free to copy, distribute and make commercial use
// of this software under the following conditions:
// * You cite the author and copyright owner: "www.embeddedsw.net"
// * You provide a link to the Homepage: "www.embeddedsw.net/libobfuscate.html"
//
///////////////////////////////////////////////

#include "stdafx.h"
#include "libObfuscate.h"

BEGIN_MESSAGE_MAP(libObfuscate, CWinApp)
	//{{AFX_MSG_MAP(libObfuscate)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVaffaApp construction

libObfuscate::libObfuscate()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

BOOL libObfuscate::InitInstance() 
{
	if(!CWinApp::InitInstance())
		{ return(FALSE); }

	//...

	return(TRUE);
}

int libObfuscate::ExitInstance()
{
	//...

	return(CWinApp::ExitInstance());
}

libObfuscate theApp;
