///////////////////////////////////////////////
//
// **************************
// ** ENGLISH - 10/Jul/2017 **
//
// Project: libObfuscate v2.00
//
// This software is released under:
// * LGPL 3.0: "www.gnu.org/licenses/lgpl.html"
//
// You�re free to copy, distribute and make commercial use
// of this software under the following conditions:
// * You cite the author and copyright owner: "www.embeddedsw.net"
// * You provide a link to the Homepage: "www.embeddedsw.net/libobfuscate.html"
//
///////////////////////////////////////////////

#ifndef	LIBOBFUSCATEDEF_H
#define	LIBOBFUSCATEDEF_H

#include "libObfuscateDef\CommonDef.h"

#include "libObfuscateDef\Grostl512_data.h"
#include "libObfuscateDef\Keccak512_data.h"
#include "libObfuscateDef\Sha512_data.h"
#include "libObfuscateDef\Skein512_data.h"

#include "libObfuscateDef\Scramble_data.h"
#include "libObfuscateDef\Multi_data.h"

#endif
