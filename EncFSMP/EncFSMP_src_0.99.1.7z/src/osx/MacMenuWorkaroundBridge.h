// MacMenuWorkaroundBridge.h

// Code from StackOverflow user fardjad
// See: http://stackoverflow.com/questions/16482471/empty-wxwidgets-menus-on-osx

#ifndef __wxstarter__MacMenuWorkaroundBridge__
#define __wxstarter__MacMenuWorkaroundBridge__

namespace CocoaBridge {
    void hideEmptyMenus();
}

#endif /* defined(__wxstarter__MacMenuWorkaroundBridge__) */
